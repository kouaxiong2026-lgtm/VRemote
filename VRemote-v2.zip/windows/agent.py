# VRemote Agent v2 (Windows 10/11, WebRTC)
import asyncio, json, os, sys, random, threading, ctypes, hmac, hashlib, time, secrets, urllib.request
import tkinter as tk
from tkinter import messagebox
import websockets, mss, numpy as np, pyautogui, pyperclip
from av import VideoFrame
from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack, RTCConfiguration, RTCIceServer

CFG = os.path.join(os.environ.get("APPDATA", "."), "vremote.json")
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
pyautogui.FAILSAFE = False; pyautogui.PAUSE = 0
try: ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception: pass
KEYS = {"Enter": "enter", "Backspace": "backspace", " ": "space", "Escape": "esc", "Tab": "tab",
        "ArrowUp": "up", "ArrowDown": "down", "ArrowLeft": "left", "ArrowRight": "right", "Control": "ctrl",
        "Shift": "shift", "Alt": "alt", "Meta": "win", "Delete": "delete", "Home": "home", "End": "end",
        "PageUp": "pageup", "PageDown": "pagedown", "CapsLock": "capslock"}

def load():
    try: return json.load(open(CFG))
    except Exception: return {}
cfg = load()
def save(): json.dump(cfg, open(CFG, "w"))
if "id" not in cfg:
    cfg["id"] = str(random.randint(100_000_000, 999_999_999))
    cfg["pass"] = secrets.token_urlsafe(6); save()
SERVER = "wss://YOUR-DOMAIN.com"   # ຖືກແທນທີ່ອັດຕະໂນມັດຕອນ build ຈາກ SERVER_URL

def autostart_on():
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k: winreg.QueryValueEx(k, "VRemote"); return True
    except OSError: return False
def set_autostart(on):
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
        if on:
            cmd = f'"{sys.executable}" --auto' if getattr(sys, "frozen", False) else \
                  f'"{sys.executable.replace("python.exe", "pythonw.exe")}" "{os.path.abspath(__file__)}" --auto'
            winreg.SetValueEx(k, "VRemote", 0, winreg.REG_SZ, cmd)
        else:
            try: winreg.DeleteValue(k, "VRemote")
            except OSError: pass

_tl = threading.local()
def grab():
    if not hasattr(_tl, "s"): _tl.s = mss.mss()
    mon = _tl.s.monitors[1]; return np.array(_tl.s.grab(mon)), mon

class ScreenTrack(VideoStreamTrack):
    def __init__(self, agent): super().__init__(); self.agent = agent
    async def recv(self):
        pts, tb = await self.next_timestamp()
        img, self.agent.mon = await asyncio.to_thread(grab)
        f = VideoFrame.from_ndarray(img, format="bgra")
        w = min(1280, f.width) // 2 * 2; h = int(f.height * w / f.width) // 2 * 2
        f = f.reformat(width=w, height=h, format="yuv420p"); f.pts, f.time_base = pts, tb
        return f

class Agent:
    def __init__(self, status_cb):
        self.status = status_cb
        self.peers = {}; self.fails = []; self.mon = None; self.loop = None; self.task = None

    def start(self):
        if self.task: return
        def run():
            self.loop = asyncio.new_event_loop(); asyncio.set_event_loop(self.loop)
            self.task = self.loop.create_task(self.main())
            try: self.loop.run_until_complete(self.task)
            except asyncio.CancelledError: pass
            self.task = None
        threading.Thread(target=run, daemon=True).start()
    def stop(self):
        if self.loop and self.task: self.loop.call_soon_threadsafe(self.task.cancel)
        self.status("ປິດຢູ່")

    def count(self): return sum(1 for p in self.peers.values() if p.get("pc") and p["pc"].connectionState == "connected")
    def refresh(self):
        n = self.count(); self.status(f"ມີຄົນຄວບຄຸມຢູ່ ({n})" if n else "ອອນລາຍ - ພ້ອມໃຫ້ຄວບຄຸມ")
    def locked(self):
        now = time.time(); self.fails = [t for t in self.fails if now - t < 60]; return len(self.fails) >= 5

    async def main(self):
        while True:
            try:
                async with websockets.connect(SERVER, max_size=2**17) as ws:
                    await ws.send(json.dumps({"t": "host", "id": cfg["id"], "pass": ""}))
                    self.refresh()
                    try:
                        async for msg in ws: await self.handle(ws, json.loads(msg))
                    finally:
                        for p in self.peers.values():
                            if p.get("pc"): await p["pc"].close()
                        self.peers.clear()
            except asyncio.CancelledError: raise
            except Exception: self.status("ກຳລັງເຊື່ອມຕໍ່ໃໝ່...")
            await asyncio.sleep(3)

    def ice(self):
        base = SERVER.replace("wss://", "https://", 1).replace("ws://", "http://", 1)
        try:
            d = json.load(urllib.request.urlopen(base + "/ice", timeout=5))
            return [RTCIceServer(urls=s["urls"], username=s.get("username"), credential=s.get("credential")) for s in d]
        except Exception: return [RTCIceServer("stun:stun.l.google.com:19302")]

    async def handle(self, ws, m):
        t, sid = m.get("t"), m.get("from")
        async def reply(o): await ws.send(json.dumps({**o, "to": sid}))
        p = self.peers.get(sid)
        if t == "join":
            if self.locked(): return await reply({"t": "err", "m": "ຖືກລັອກຊົ່ວຄາວ ລອງໃໝ່ພາຍຫຼັງ 1 ນາທີ"})
            n = secrets.token_hex(16); self.peers[sid] = {"nonce": n}; await reply({"t": "challenge", "nonce": n})
        elif t == "auth" and p and "nonce" in p:
            exp = hmac.new(cfg["pass"].encode(), p.pop("nonce").encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(exp, str(m.get("h", ""))):
                self.fails.append(time.time()); return await reply({"t": "err", "m": "ລະຫັດຜ່ານບໍ່ຖືກຕ້ອງ"})
            p["ok"] = True; await reply({"t": "authed"})
        elif t == "offer" and p and p.get("ok") and not p.get("pc"):
            pc = RTCPeerConnection(RTCConfiguration(await asyncio.to_thread(self.ice))); p["pc"] = pc
            @pc.on("datachannel")
            def _(ch): ch.on("message", lambda msg: self.apply(json.loads(msg)))
            @pc.on("connectionstatechange")
            async def _():
                if pc.connectionState in ("failed", "closed", "disconnected"):
                    await pc.close(); self.peers.pop(sid, None)
                self.refresh()
            await pc.setRemoteDescription(RTCSessionDescription(m["sdp"], "offer"))
            pc.addTrack(ScreenTrack(self))
            await pc.setLocalDescription(await pc.createAnswer())
            await reply({"t": "answer", "sdp": pc.localDescription.sdp})
        elif t == "bye" and p:
            if p.get("pc"): await p["pc"].close()
            self.peers.pop(sid, None); self.refresh()

    def apply(self, m):
        try:
            e, mon = m["e"], self.mon
            if e in ("m", "d", "u") and mon:
                x = int(mon["left"] + m["x"] * mon["width"]); y = int(mon["top"] + m["y"] * mon["height"])
                if e == "m": pyautogui.moveTo(x, y)
                elif e == "d": pyautogui.mouseDown(x, y, button=m.get("b", "left"))
                else: pyautogui.mouseUp(x, y, button=m.get("b", "left"))
            elif e == "w": pyautogui.scroll(-int(m["dy"] * 1.2))
            elif e in ("kd", "ku"):
                k = KEYS.get(m["key"], m["key"].lower())
                if k in pyautogui.KEYBOARD_KEYS: (pyautogui.keyDown if e == "kd" else pyautogui.keyUp)(k)
            elif e == "txt": pyperclip.copy(m["s"]); pyautogui.hotkey("ctrl", "v")
        except Exception: pass

root = tk.Tk(); root.title("VRemote - ຄວບຄຸມໄລຍະໄກ"); root.geometry("380x340")
F = ("Leelawadee UI", 12); st = tk.StringVar(value="ປິດຢູ່")
agent = Agent(lambda s: root.after(0, st.set, s))
tk.Label(root, text="ID ຂອງເຄື່ອງນີ້", font=F).pack(pady=(10, 0))
tk.Label(root, text=f'{cfg["id"][:3]} {cfg["id"][3:6]} {cfg["id"][6:]}', font=("Consolas", 24, "bold"), fg="#1565c0").pack()
tk.Label(root, text="ລະຫັດຜ່ານ (ປ່ຽນໄດ້)", font=F).pack(pady=(8, 0))
pw = tk.Entry(root, font=("Consolas", 16), justify="center"); pw.insert(0, cfg["pass"]); pw.pack()
tk.Label(root, textvariable=st, font=F, fg="#2e7d32").pack(pady=4)

def toggle():
    if agent.task: agent.stop(); btn.config(text="ເປີດການຄວບຄຸມ", bg="#2e7d32")
    else:
        if len(pw.get().strip()) < 6: return messagebox.showwarning("VRemote", "ລະຫັດຜ່ານຕ້ອງມີຢ່າງໜ້ອຍ 6 ຕົວ")
        cfg["pass"] = pw.get().strip(); save()
        agent.start(); btn.config(text="ປິດການຄວບຄຸມ", bg="#c62828")
btn = tk.Button(root, text="ເປີດການຄວບຄຸມ", font=F, bg="#2e7d32", fg="white", width=26, command=toggle); btn.pack(pady=4)
def refresh_auto(): ab.config(text="ເປີດອັດຕະໂນມັດຕອນເປີດເຄື່ອງ: " + ("ເປີດ ✔" if autostart_on() else "ປິດ"))
ab = tk.Button(root, font=F, width=36, command=lambda: (set_autostart(not autostart_on()), refresh_auto())); ab.pack(pady=4)
refresh_auto()
root.after(500, toggle)   # ເປີດໃຫ້ຄວບຄຸມທັນທີເມື່ອເປີດໂປຣແກຣມ
if "--auto" in sys.argv: root.after(1500, root.iconify)
root.mainloop()
