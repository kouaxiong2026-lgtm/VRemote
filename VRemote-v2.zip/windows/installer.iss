[Setup]
AppName=VRemote
AppVersion=2.0
DefaultDirName={autopf}\VRemote
DefaultGroupName=VRemote
OutputDir=..\dist
OutputBaseFilename=VRemote-Setup
Compression=lzma
PrivilegesRequired=admin
[Files]
Source: "..\dist\VRemote.exe"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{group}\VRemote"; Filename: "{app}\VRemote.exe"
Name: "{autodesktop}\VRemote"; Filename: "{app}\VRemote.exe"
[Tasks]
Name: "autostart"; Description: "Start VRemote automatically when Windows starts"
[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueName: "VRemote"; ValueType: string; ValueData: """{app}\VRemote.exe"" --auto"; Tasks: autostart
[Run]
Filename: "{app}\VRemote.exe"; Description: "Launch VRemote"; Flags: postinstall nowait skipifsilent
