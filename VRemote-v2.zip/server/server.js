// VRemote signaling server (WebRTC)  —  npm i ws && node server.js
// env: PORT, TURN_HOST, TURN_SECRET (coturn use-auth-secret)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {WebSocketServer}=require('ws');
const send=(ws,o)=>ws&&ws.readyState===1&&ws.send(JSON.stringify(o));
const hosts=new Map(), joins=new Map();
const server=http.createServer((req,res)=>{
  if(req.url==='/ice'){
    const s=[{urls:'stun:stun.l.google.com:19302'}], H=process.env.TURN_HOST, K=process.env.TURN_SECRET;
    if(H&&K){const u=String(Math.floor(Date.now()/1000)+3600);
      s.push({urls:[`turn:${H}:3478?transport=udp`,`turn:${H}:3478?transport=tcp`],username:u,
        credential:crypto.createHmac('sha1',K).update(u).digest('base64')});}
    res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify(s));}
  if(req.url==='/'||req.url==='/index.html'){
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','X-Frame-Options':'DENY'});
    return res.end(fs.readFileSync(path.join(__dirname,'index.html')));}
  res.writeHead(404);res.end();});
const wss=new WebSocketServer({server,maxPayload:64*1024});
wss.on('connection',(ws,req)=>{
  const ip=req.headers['x-forwarded-for']||req.socket.remoteAddress;
  ws.sid=crypto.randomBytes(8).toString('hex');
  ws.on('message',d=>{
    let m;try{m=JSON.parse(d)}catch{return}
    if(m.t==='host'){const id=String(m.id);const o=hosts.get(id);
      if(o&&o.readyState===1)return send(ws,{t:'err',m:'ID ນີ້ຖືກໃຊ້ແລ້ວ'});
      ws.hid=id;ws.peers=new Map();hosts.set(id,ws);send(ws,{t:'ok'});}
    else if(m.t==='join'){
      const now=Date.now(),a=(joins.get(ip)||[]).filter(t=>now-t<60000);a.push(now);joins.set(ip,a);
      if(a.length>20)return send(ws,{t:'err',m:'ລອງຫຼາຍເກີນໄປ ກະລຸນາລໍຖ້າ 1 ນາທີ'});
      const h=hosts.get(String(m.id));
      if(!h||h.readyState!==1)return send(ws,{t:'err',m:'ບໍ່ພົບອຸປະກອນ ຫຼື ອຸປະກອນອອບໄລນ໌'});
      ws.host=h;h.peers.set(ws.sid,ws);send(h,{t:'join',from:ws.sid});}
    else if(ws.host&&['auth','offer'].includes(m.t))send(ws.host,{t:m.t,h:m.h,sdp:m.sdp,from:ws.sid});
    else if(ws.hid&&m.to&&['challenge','authed','answer','err'].includes(m.t)){
      const v=ws.peers.get(m.to);if(v)send(v,{t:m.t,nonce:m.nonce,sdp:m.sdp,m:m.m});}
  });
  ws.on('close',()=>{
    if(ws.hid&&hosts.get(ws.hid)===ws){for(const v of ws.peers.values())send(v,{t:'err',m:'ອຸປະກອນຕັດການເຊື່ອມຕໍ່'});hosts.delete(ws.hid);}
    if(ws.host){ws.host.peers.delete(ws.sid);send(ws.host,{t:'bye',from:ws.sid});}});
});
server.listen(process.env.PORT||8080,()=>console.log('VRemote server up'));
