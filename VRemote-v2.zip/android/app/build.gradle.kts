plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
val serverUrl = (project.findProperty("serverUrl") as String?)?.takeIf { it.isNotBlank() } ?: "https://YOUR-DOMAIN.com"
android {
    namespace = "com.vremote.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.vremote.app"; minSdk = 24; targetSdk = 34; versionCode = 2; versionName = "2.0"
        buildConfigField("String", "SERVER_URL", "\"$serverUrl\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
